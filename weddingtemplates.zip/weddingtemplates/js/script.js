
$(document).ready(function(){


	/* ---- Countdown timer ---- */
//alert(new Date('2018-08-31') - new Date());
//alert(new Date() - 'Fri aug 31 2018 06:00:00 GMT+0530 (IST)' );
	$('#counter').countdown({
		timestamp : new Date("2019-01-23T06:00:00") //(new Date()).getTime() +  ((new Date()).getTime() - 39) //08*10*60*60*1000
	});


	/* ---- Animations ---- */

	$('#links a').hover(
		function(){ $(this).animate({ left: 3 }, 'fast'); },
		function(){ $(this).animate({ left: 0 }, 'fast'); }
	);

	$('footer a').hover(
		function(){ $(this).animate({ top: 3 }, 'fast'); },
		function(){ $(this).animate({ top: 0 }, 'fast'); }
	);




});
